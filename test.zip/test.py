import os
import ffmpeg
import subprocess

def add_subtitles_with_ass(video_path, ass_path, output_path):

    video_path = os.path.abspath(video_path)
    ass_path = os.path.abspath(ass_path)
    output_path = os.path.abspath(output_path)

    print(f"🚀 Add susbtitiles with ASS : {ass_path}")
    ass_path_escaped = rf'"{ass_path}"'

    try:
        ffmpeg.input(video_path).output(output_path, vf=f"ass='{ass_path_escaped}'").run(overwrite_output=True)
        print(f"✅ Subtitles added with success : {output_path}")
    except Exception as e:
        print(f"❌ ERROR when adding subtitles : {e}")


def add_subtitles_with_ass_with_subprocess(video_path, ass_path, output_path):
    video_path = os.path.abspath(video_path)
    ass_path = os.path.abspath(ass_path)
    output_path = os.path.abspath(output_path)

    print(f"🚀 Add subtitles with ASS : {ass_path}")

    try:
        command = [
            'ffmpeg',
            '-i', video_path,
            '-vf', f"ass='{ass_path}'",
            '-c:a', 'copy',
            output_path,
            '-y'  # Overwrite output file without asking
        ]

        subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        print(f"✅ Subtitles added with success : {output_path}")
    except subprocess.CalledProcessError as e:
        print(f"❌ ERROR when adding subtitles : {e.stderr.decode('utf-8')}")


print(f"Test 1 -----------------------------------------------------------------------")
ass_path="G:\Mi unidad\Python\Scripts\shorts_videos\10000views_and_higher\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.ass"
video_path="G:\Mi unidad\Python\Scripts\shorts_videos\10000views_and_higher\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo.mp4"
output_path="G:\Mi unidad\Python\Scripts\shorts_videos\10000views_and_higher\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.mp4"
add_subtitles_with_ass(video_path, ass_path, output_path)
print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 2 -----------------------------------------------------------------------")
ass_path2="G:\\Mi unidad\\Python\\Scripts\\shorts_videos\\10000views_and_higher\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.ass"
video_path2="G:\\Mi unidad\\Python\\Scripts\\shorts_videos\\10000views_and_higher\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo.mp4"
output_path2="G:\\Mi unidad\\Python\\Scripts\\shorts_videos\\10000views_and_higher\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.mp4"
add_subtitles_with_ass(video_path2, ass_path2, output_path2)

print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 3 -----------------------------------------------------------------------")
ass_path3="G:/\Mi unidad/\Python/\Scripts/\shorts_videos/\10000views_and_higher/\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.ass"
video_path3="G:/\Mi unidad/\Python/\Scripts/\shorts_videos/\10000views_and_higher/\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo.mp4"
output_path3="G:/\Mi unidad/\Python/\Scripts/\shorts_videos/\10000views_and_higher/\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.mp4"
add_subtitles_with_ass(video_path3, ass_path3, output_path3)

print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 4 -----------------------------------------------------------------------")
ass_path4="G:/\\Mi unidad/\\Python/\\Scripts/\\shorts_videos/\\10000views_and_higher/\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.ass"
video_path4="G:/\\Mi unidad/\\Python/\\Scripts/\\shorts_videos/\\10000views_and_higher/\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo.mp4"
output_path4="G:/\\Mi unidad/\\Python/\\Scripts/\\shorts_videos/\\10000views_and_higher/\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.mp4"
add_subtitles_with_ass(video_path4, ass_path4, output_path4)




print(f"Test 1 with subprocess -----------------------------------------------------------------------")
add_subtitles_with_ass_with_subprocess(video_path, ass_path, output_path)
print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 2 with subprocess -----------------------------------------------------------------------")
add_subtitles_with_ass_with_subprocess(video_path2, ass_path2, output_path2)
print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 3 with subprocess -----------------------------------------------------------------------")
add_subtitles_with_ass_with_subprocess(video_path3, ass_path3, output_path3)
print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 4 with subprocess -----------------------------------------------------------------------")
add_subtitles_with_ass_with_subprocess(video_path4, ass_path4, output_path4)
print(50*"*")
print(50*"*")
print(50*"*")

#======================= IT DIDN'T WORK, SO LET'S DO WITH RELATIVE PATH ===================================


print(f"Test 1 with relative path -----------------------------------------------------------------------")
ass_path_relative="10000views_and_higher\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.ass"
video_path_relative="10000views_and_higher\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo.mp4"
output_path_relative="10000views_and_higher\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.mp4"
add_subtitles_with_ass(video_path_relative, ass_path_relative, output_path_relative)
print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 2  with relative path -----------------------------------------------------------------------")
ass_path2_relative="10000views_and_higher\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.ass"
video_path2_relative="10000views_and_higher\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo.mp4"
output_path2_relative="10000views_and_higher\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.mp4"
add_subtitles_with_ass(video_path2_relative, ass_path2_relative, output_path2_relative)

print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 3  with relative path -----------------------------------------------------------------------")
ass_path3_relative="10000views_and_higher/\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.ass"
video_path3_relative="10000views_and_higher/\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo.mp4"
output_path3_relative="10000views_and_higher/\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.mp4"
add_subtitles_with_ass(video_path3_relative, ass_path3_relative, output_path3_relative)

print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 4  with relative path -----------------------------------------------------------------------")
ass_path4_relative="10000views_and_higher/\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.ass"
video_path4_relative="10000views_and_higher/\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo.mp4"
output_path4_relative="10000views_and_higher/\\Li2zY7XcOf0_Matthew_Hussey_flip_h_BW_with_logo_EN.mp4"
add_subtitles_with_ass(video_path4_relative, ass_path4_relative, output_path4_relative)




print(f"Test 1 with subprocess  with relative path -----------------------------------------------------------------------")
add_subtitles_with_ass_with_subprocess(video_path, ass_path, output_path)
print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 2 with subprocess  with relative path -----------------------------------------------------------------------")
add_subtitles_with_ass_with_subprocess(video_path2_relative, ass_path2_relative, output_path2_relative)
print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 3 with subprocess  with relative path -----------------------------------------------------------------------")
add_subtitles_with_ass_with_subprocess(video_path3_relative, ass_path3_relative, output_path3_relative)
print(50*"*")
print(50*"*")
print(50*"*")

print(f"Test 4 with subprocess  with relative path -----------------------------------------------------------------------")
add_subtitles_with_ass_with_subprocess(video_path4_relative, ass_path4_relative, output_path4_relative)
print(50*"*")
print(50*"*")
print(50*"*")



